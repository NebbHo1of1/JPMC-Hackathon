import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

def calculate_need_score(data, enrollment_weight=0.5, performance_weight=0.5):
    """
    Calculate a need score for each district based on enrollment and performance metrics.
    
    Args:
        data (DataFrame): The processed district data
        enrollment_weight (float): Weight for enrollment-related metrics (0-1)
        performance_weight (float): Weight for performance-related metrics (0-1)
        
    Returns:
        DataFrame: Original data with need score added
    """
    # Copy data to avoid modifying original
    result = data.copy()
    
    # Normalize metrics using MinMaxScaler
    scaler = MinMaxScaler()
    
    # Normalize enrollment metric (higher enrollment with low performance is worse)
    if 'student_enrollment' in result.columns:
        result['enrollment_score'] = scaler.fit_transform(result[['student_enrollment']])
    
    # Normalize performance metrics (lower is worse)
    performance_columns = []
    
    if 'read_test_pct_prof_midpt' in result.columns:
        result['reading_score'] = 1 - scaler.fit_transform(result[['read_test_pct_prof_midpt']])
        performance_columns.append('reading_score')
    
    if 'math_test_pct_prof_midpt' in result.columns:
        result['math_score'] = 1 - scaler.fit_transform(result[['math_test_pct_prof_midpt']])
        performance_columns.append('math_score')
    
    # Normalize resource metrics (lower is worse)
    if 'funding_per_student' in result.columns:
        result['funding_score'] = 1 - scaler.fit_transform(result[['funding_per_student']])
        performance_columns.append('funding_score')
    
    if 'school_count' in result.columns:
        result['school_access_score'] = 1 - scaler.fit_transform(result[['school_count']])
    
    # Calculate composite enrollment score
    enrollment_metrics = [col for col in ['enrollment_score'] if col in result.columns]
    
    if enrollment_metrics:
        result['composite_enrollment_score'] = result[enrollment_metrics].mean(axis=1)
    else:
        result['composite_enrollment_score'] = 0
    
    # Calculate composite performance score
    if performance_columns:
        result['composite_performance_score'] = result[performance_columns].mean(axis=1)
    else:
        result['composite_performance_score'] = 0
    
    # Calculate final need score with weights
    result['need_score'] = (
        enrollment_weight * result['composite_enrollment_score'] +
        performance_weight * result['composite_performance_score']
    )
    
    return result

def get_recommendations(data, enrollment_weight=0.5, performance_weight=0.5, n=10):
    """
    Get recommended districts for intervention based on need score.
    
    Args:
        data (DataFrame): The processed district data
        enrollment_weight (float): Weight for enrollment-related metrics (0-1)
        performance_weight (float): Weight for performance-related metrics (0-1)
        n (int): Number of recommendations to return
        
    Returns:
        DataFrame: Top n districts by need score
    """
    # Calculate need score
    scored_data = calculate_need_score(
        data, 
        enrollment_weight=enrollment_weight, 
        performance_weight=performance_weight
    )
    
    # Sort by need score (higher is higher need)
    recommendations = scored_data.sort_values('need_score', ascending=False).head(n)
    
    # Select relevant columns for output
    output_columns = [
        'district_name', 'region', 'need_score', 
        'student_enrollment', 'read_test_pct_prof_midpt', 'math_test_pct_prof_midpt',
        'funding_per_student', 'school_count'
    ]
    
    # Only include columns that exist
    output_columns = [col for col in output_columns if col in recommendations.columns]
    
    return recommendations[output_columns]

def identify_underserved(data, threshold_percentile=75):
    """
    Identify underserved districts based on a need score threshold.
    
    Args:
        data (DataFrame): The processed district data
        threshold_percentile (int): Percentile threshold for identifying underserved districts
        
    Returns:
        DataFrame: Districts identified as underserved
    """
    # Calculate need score with balanced weights
    scored_data = calculate_need_score(data)
    
    # Calculate threshold value
    threshold = np.percentile(scored_data['need_score'], threshold_percentile)
    
    # Identify underserved districts
    underserved = scored_data[scored_data['need_score'] >= threshold].copy()
    
    # Add underserved flag and rank
    underserved['is_underserved'] = True
    underserved['underserved_rank'] = underserved['need_score'].rank(ascending=False)
    
    # Select relevant columns
    output_columns = [
        'district_name', 'region', 'need_score', 'underserved_rank',
        'student_enrollment', 'read_test_pct_prof_midpt', 'math_test_pct_prof_midpt',
        'funding_per_student', 'school_count'
    ]
    
    # Only include columns that exist
    output_columns = [col for col in output_columns if col in underserved.columns]
    
    return underserved[output_columns].sort_values('need_score', ascending=False)
