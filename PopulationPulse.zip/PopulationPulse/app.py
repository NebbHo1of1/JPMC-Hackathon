import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import os
from data_processor import load_data, preprocess_data
from recommendation_engine import get_recommendations, identify_underserved
from visualization import create_choropleth_map, create_metric_charts

# Set page configuration
st.set_page_config(
    page_title="Micropolitan District Recommendation System",
    page_icon="🏫",
    layout="wide"
)

# Application title and description
st.title("Micropolitan District Recommendation System")
st.markdown("""
This application helps identify and recommend micropolitan school districts across the United States
based on student enrollment, educational performance, and financial metrics. Use the interactive map and controls
to explore districts and generate recommendations for targeted interventions.
""")

# Sidebar controls
st.sidebar.header("Control Panel")

# Data loading section
@st.cache_data
def get_data():
    """
    Load and process the district data.
    Note: This function is cached to improve performance.
    """
    try:
        # In a real scenario, data would be loaded from files
        # For now, we'll create a placeholder for demonstration
        data = load_data()
        processed_data = preprocess_data(data)
        return processed_data
    except Exception as e:
        st.error(f"Error loading data: {str(e)}")
        return None

# Load data
data = get_data()

if data is None:
    st.warning("""
    ### No data available
    
    This application requires regional micropolitan district data to function. 
    Please ensure the data files are available in the expected location.
    
    Expected data format:
    - CSV files with district information
    - GeoJSON files for mapping
    - Metrics including population in poverty, district count, etc.
    """)
else:
    # Main application layout (when data is available)
    
    # District selection dropdown
    st.subheader("District Selection")
    all_districts = sorted(data['district_name'].unique())
    selected_district = st.selectbox(
        "Select a district to view metrics:",
        options=all_districts
    )
    
    # Store selected district in session state
    st.session_state.selected_district = selected_district
    
    # Display district metrics
    st.subheader("District Metrics")
    metrics = data[data['district_name'] == selected_district].iloc[0]
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("Student Enrollment", f"{metrics['student_enrollment']:,}")
        st.metric("Reading Proficiency", f"{metrics['read_test_pct_prof_midpt']:.1f}%" if 'read_test_pct_prof_midpt' in metrics else "N/A")
    
    with col2:
        st.metric("Math Proficiency", f"{metrics['math_test_pct_prof_midpt']:.1f}%" if 'math_test_pct_prof_midpt' in metrics else "N/A")
        st.metric("Number of Schools", f"{metrics['school_count']:,}")
    
    if 'funding_per_student' in metrics:
        st.metric("Funding per Student", f"${metrics['funding_per_student']:,.2f}")
    
    # Recommendation section
    st.header("District Recommendations")
    
    # Recommendation parameters
    st.subheader("Customize Recommendation Parameters")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        enrollment_weight = st.slider("Enrollment Weight", 0.0, 1.0, 0.5, 0.1)
    with col2:
        performance_weight = st.slider("Performance Weight", 0.0, 1.0, 0.5, 0.1)
    with col3:
        num_recommendations = st.slider("Number of Recommendations", 5, 20, 10)
    
    # Generate recommendations
    if st.button("Generate Recommendations"):
        with st.spinner("Analyzing district data..."):
            recommendations = get_recommendations(
                data, 
                enrollment_weight=enrollment_weight,
                performance_weight=performance_weight,
                n=num_recommendations
            )
            
            st.subheader("Recommended Districts for Intervention")
            st.dataframe(recommendations)
            
            # Option to download recommendations
            csv = recommendations.to_csv(index=False)
            st.download_button(
                label="Download Recommendations as CSV",
                data=csv,
                file_name="district_recommendations.csv",
                mime="text/csv"
            )
    
    # Underserved district identification
    st.header("Underserved District Identification")
    
    threshold = st.slider(
        "Underserved Threshold (percentile)", 
        0, 100, 75, 
        help="Districts above this percentile in the combined score will be identified as underserved"
    )
    
    if st.button("Identify Underserved Districts"):
        with st.spinner("Analyzing underserved districts..."):
            underserved = identify_underserved(data, threshold_percentile=threshold)
            
            st.subheader(f"Most Underserved Districts ({len(underserved)} identified)")
            st.dataframe(underserved)
            
            # Option to download underserved list
            csv_underserved = underserved.to_csv(index=False)
            st.download_button(
                label="Download Underserved Districts as CSV",
                data=csv_underserved,
                file_name="underserved_districts.csv",
                mime="text/csv"
            )

# Instructions section
with st.expander("How to Use This Application"):
    st.markdown("""
    ### Using the Micropolitan District Recommendation System
    
    1. **District Selection**: 
       - Use the dropdown menu to select a district
       - View detailed metrics and statistics for the selected district
    
    2. **Generate Recommendations**:
       - Adjust the weights to prioritize different factors (enrollment size and performance metrics)
       - Click "Generate Recommendations" to see districts that may need intervention
       - The recommendations are based on a combination of enrollment figures and educational performance
    
    3. **Identify Underserved Districts**:
       - Set the threshold percentile to determine which districts are considered underserved
       - The system will identify districts that meet or exceed this threshold
       - These districts typically have large enrollments with lower performance metrics
    
    4. **Data Exploration**:
       - Download data for offline analysis
       - Use the CSV exports to perform more detailed analysis
    
    ### About the Data
    
    This application uses data on micropolitan school districts including:
    - Student enrollment figures
    - Reading and math proficiency test results
    - Revenue sources (local, state, federal)
    - School district resource allocation 
    - Geographic location information
    
    Data is processed and normalized to allow for fair comparisons across different regions.
    """)

# Footer
st.markdown("---")
st.markdown("© 2023 Micropolitan District Recommendation System | Data is for analytical purposes only")
