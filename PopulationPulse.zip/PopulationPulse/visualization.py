import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np

def create_choropleth_map(data, metric, highlight_districts=None):
    """
    Create an interactive choropleth map for the given metric.
    
    Args:
        data (DataFrame): The processed district data
        metric (str): The metric to visualize on the map
        highlight_districts (list, optional): List of district names to highlight
        
    Returns:
        plotly.graph_objects.Figure: The choropleth map figure
    """
    # Map the metric name to the actual column name
    metric_mapping = {
        "Student Enrollment": "student_enrollment",
        "Total Revenue": "rev_total",
        "Local Revenue": "rev_local_total",
        "State Revenue": "rev_state_total",
        "Federal Revenue": "rev_fed_total",
        "Reading Proficiency": "read_test_pct_prof_midpt",
        "Math Proficiency": "math_test_pct_prof_midpt",
        "School Count": "school_count",
        "Funding per Student": "funding_per_student"
    }
    
    column = metric_mapping.get(metric, metric)
    
    # If we don't have actual GeoJSON data, we'll create a simpler map visualization
    # In a real implementation, this would use proper GeoJSON with district boundaries
    
    # Create a base map (this is simplified - real implementation would use GeoJSON)
    if 'latitude' in data.columns and 'longitude' in data.columns:
        if highlight_districts is not None:
            # Add a column to indicate if district should be highlighted
            data = data.copy()
            data['highlighted'] = data['district_name'].isin(highlight_districts)
            
            # Create scatter mapbox with highlighted districts
            fig = px.scatter_mapbox(
                data,
                lat='latitude',
                lon='longitude',
                color=column,
                size='student_enrollment',
                hover_name='district_name',
                hover_data={
                    'student_enrollment': ':,',
                    'read_test_pct_prof_midpt': ':.1f%',
                    'math_test_pct_prof_midpt': ':.1f%',
                    'funding_per_student': ':$,.2f',
                    'school_count': ':,',
                    'latitude': False,
                    'longitude': False
                },
                color_continuous_scale='YlOrRd',
                size_max=25,
                zoom=3,
                opacity=0.8,
                title=f"{metric} by District"
            )
            
            # Add highlighted districts with different marker
            highlight_data = data[data['highlighted']]
            if not highlight_data.empty:
                fig.add_trace(
                    go.Scattermapbox(
                        lat=highlight_data['latitude'],
                        lon=highlight_data['longitude'],
                        mode='markers',
                        marker=dict(
                            size=15,
                            color='rgba(0, 255, 0, 0.8)',
                            line=dict(width=2, color='black')
                        ),
                        text=highlight_data['district_name'],
                        hoverinfo='text',
                        name='Highlighted Districts'
                    )
                )
        else:
            # Create standard scatter mapbox
            fig = px.scatter_mapbox(
                data,
                lat='latitude',
                lon='longitude',
                color=column,
                size='student_enrollment',
                hover_name='district_name',
                hover_data={
                    'student_enrollment': ':,',
                    'read_test_pct_prof_midpt': ':.1f%',
                    'math_test_pct_prof_midpt': ':.1f%',
                    'funding_per_student': ':$,.2f',
                    'school_count': ':,',
                    'latitude': False,
                    'longitude': False
                },
                color_continuous_scale='YlOrRd',
                size_max=25,
                zoom=3,
                opacity=0.7,
                title=f"{metric} by District"
            )
    else:
        # Fallback to a simple scatter plot if geo coordinates aren't available
        fig = px.scatter(
            data,
            x='region',
            y=column,
            size='student_enrollment',
            color=column,
            hover_name='district_name',
            title=f"{metric} by Region (Map data not available)",
            color_continuous_scale='YlOrRd'
        )
    
    # Update map layout
    fig.update_layout(
        mapbox_style="carto-positron",
        margin={"r": 0, "t": 40, "l": 0, "b": 0},
        coloraxis_colorbar=dict(
            title=metric
        ),
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="left",
            x=0.01
        )
    )
    
    # Add click event for district selection
    fig.update_traces(
        customdata=data['district_name'],
    )
    
    return fig

def create_metric_charts(data, selected_district):
    """
    Create charts comparing the selected district metrics to averages.
    
    Args:
        data (DataFrame): The processed district data
        selected_district (str): The name of the selected district
        
    Returns:
        plotly.graph_objects.Figure: The comparison chart figure
    """
    # Get data for the selected district
    district_data = data[data['district_name'] == selected_district].iloc[0]
    
    # Calculate averages
    avg_data = data.mean()
    
    # Define metrics to compare
    metrics = [
        {'name': 'Student Enrollment', 'column': 'student_enrollment'},
        {'name': 'Reading Proficiency (%)', 'column': 'read_test_pct_prof_midpt'},
        {'name': 'Math Proficiency (%)', 'column': 'math_test_pct_prof_midpt'},
        {'name': 'Funding per Student ($)', 'column': 'funding_per_student'},
        {'name': 'Schools per 1000 Students', 'column': 'schools_per_1000'}
    ]
    
    # Filter metrics to include only those in the data
    metrics = [m for m in metrics if m['column'] in district_data.index]
    
    if not metrics:
        # Fallback if none of the expected metrics are available
        metrics = [
            {'name': col, 'column': col} 
            for col in district_data.index 
            if col not in ['district_name', 'region', 'latitude', 'longitude']
        ][:5]  # Limit to 5 metrics
    
    # Create comparison chart
    fig = go.Figure()
    
    # Add district data
    fig.add_trace(go.Bar(
        x=[m['name'] for m in metrics],
        y=[district_data[m['column']] for m in metrics],
        name=selected_district,
        marker_color='royalblue'
    ))
    
    # Add average data
    fig.add_trace(go.Bar(
        x=[m['name'] for m in metrics],
        y=[avg_data[m['column']] for m in metrics],
        name='Region Average',
        marker_color='lightgray'
    ))
    
    # Update layout
    fig.update_layout(
        title=f"Metrics Comparison: {selected_district} vs. Average",
        xaxis_title="Metric",
        yaxis_title="Value",
        barmode='group',
        legend=dict(
            yanchor="top",
            y=0.99,
            xanchor="right",
            x=0.99
        )
    )
    
    return fig
