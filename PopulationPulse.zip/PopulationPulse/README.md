# Micropolitan District Recommendation System

An interactive web application for visualizing micropolitan district data and generating recommendations for underserved districts based on poverty metrics and other relevant data.

## Features

- **Interactive Choropleth Map**: Visualize key metrics across micropolitan districts
- **Data Integration**: Process and normalize data on poverty, school districts, and more
- **Recommendation Engine**: Generate district recommendations based on configurable parameters
- **Underserved District Identification**: Identify the most underserved districts based on multiple criteria
- **User Interactivity**: Adjust parameters, filter data, and explore different regions

## Setup and Running the Application

1. **Install Dependencies**:
   ```
   pip install streamlit pandas numpy plotly scikit-learn
   ```

2. **Data Preparation**:
   - Place your district data files in the appropriate format
   - Update the data loading functions if needed to match your data structure

3. **Run the Application**:
   ```
   streamlit run app.py
   ```

## Data Requirements

The application expects data with the following structure:

- **District Information**: Names, regions, geographic coordinates
- **Poverty Metrics**: Population in poverty, poverty rates
- **Educational Resources**: Number of school districts, funding per student
- **Geographic Data**: GeoJSON or coordinate data for mapping

## Usage Instructions

1. **Explore the Map**: 
   - Select metrics to visualize on the map
   - Hover over districts to see details
   - Click on districts to view comparative metrics

2. **Generate Recommendations**:
   - Adjust weights for poverty and resources
   - Set the number of recommendations to generate
   - View and download the recommended districts

3. **Identify Underserved Districts**:
   - Set the threshold percentile to define "underserved"
   - Generate and visualize underserved districts
   - Download the list for further analysis

## Customization

- **Recommendation Parameters**: Adjust the weights to prioritize different factors
- **Visualization Options**: Select different metrics to visualize on the map
- **Threshold Settings**: Customize what qualifies as an "underserved" district

## Expected Data Format

For this application to work properly, it expects data files with the following structure:

1. **District Data CSV**:
   ```
   district_name,region,latitude,longitude,poverty_population,poverty_rate,school_count,funding_per_student
   District A,Northeast,42.5,-71.2,5000,15.2,20,12500
   District B,Midwest,41.8,-87.6,8200,22.5,35,10800
   ...
   ```

2. **GeoJSON File** (optional but recommended for better mapping):
   - Standard GeoJSON format with district boundaries
   - Properties should include a field that can be matched to district names in the CSV
