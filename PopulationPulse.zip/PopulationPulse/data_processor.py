import pandas as pd
import numpy as np
import os
import json
from typing import Dict, Optional, List
import random

def load_data():
    """
    Load district data from files.
    
    Loads and combines data from multiple regional datasets.
    
    Returns:
        DataFrame: A dataframe containing district data
    """
    data_files = {
        'Midwest': 'data/midwest_data.csv',
        'Northeast': 'data/northeast_data.csv',
        'South': 'data/south_data.csv',
        'West': 'data/west_data.csv'
    }
    
    all_data = []
    
    for region_name, file_path in data_files.items():
        if os.path.exists(file_path):
            try:
                # Load the data
                region_data = pd.read_csv(file_path)
                
                # Add a region identifier column if it doesn't exist
                if 'region' not in region_data.columns:
                    region_data['region'] = region_name
                
                all_data.append(region_data)
            except Exception as e:
                print(f"Error loading {region_name} data: {str(e)}")
    
    if not all_data:
        raise FileNotFoundError(
            "Required data files are not available. Please place the dataset files in the 'data/' directory."
        )
    
    # Combine all regional datasets
    combined_data = pd.concat(all_data, ignore_index=True)
    
    # Rename columns for consistency
    column_mapping = {
        'lea_name': 'district_name',
        'enrollment': 'student_enrollment',
        'state_location': 'state'
    }
    
    for old_col, new_col in column_mapping.items():
        if old_col in combined_data.columns:
            combined_data[new_col] = combined_data[old_col]
    
    return combined_data

def preprocess_data(data):
    """
    Preprocess and normalize the district data.
    
    Args:
        data (DataFrame): Raw district data
        
    Returns:
        DataFrame: Processed and normalized data
    """
    # Create a copy to avoid modifying the original
    processed_data = data.copy()
    
    # Basic data cleaning
    # 1. Convert string columns to appropriate types
    numeric_columns = ['student_enrollment', 'rev_total', 
                       'rev_local_total', 'rev_state_total', 'rev_fed_total',
                       'read_test_pct_prof_midpt', 'math_test_pct_prof_midpt',
                       'read_test_num_valid', 'math_test_num_valid']
    
    # Handle numeric conversions more carefully
    for col in numeric_columns:
        if col in processed_data.columns:
            # First handle the data type
            if processed_data[col].dtype == 'object':
                # Replace empty strings and non-numeric values with NaN
                processed_data[col] = processed_data[col].replace('', np.nan)
                # Remove quotes, commas, and other non-numeric characters if present
                if isinstance(processed_data[col].iloc[0], str):
                    processed_data[col] = processed_data[col].str.replace(',', '')
                    processed_data[col] = processed_data[col].str.replace('"', '')
                    processed_data[col] = processed_data[col].str.replace('$', '')
                    processed_data[col] = processed_data[col].str.replace('%', '')
            
            # Convert to numeric, coercing errors to NaN
            processed_data[col] = pd.to_numeric(processed_data[col], errors='coerce')
    
    # 2. Filter to include only relevant school districts
    # Include only "Regular local school district" types if agency_type is available
    if 'agency_type' in processed_data.columns:
        processed_data = processed_data[processed_data['agency_type'].str.contains('Regular local school district', na=False)]
    
    # 3. Filter to focus on districts with necessary data
    # Keep only districts that have at least student_enrollment data
    has_data = (~pd.isna(processed_data['student_enrollment']) if 'student_enrollment' in processed_data.columns else True)
    processed_data = processed_data[has_data]
    
    # 4. Create derived metrics
    # Calculate poverty rate (if it doesn't exist) based on federal revenue as a proxy
    if 'poverty_rate' not in processed_data.columns and 'rev_fed_total' in processed_data.columns and 'student_enrollment' in processed_data.columns:
        # Calculate poverty rate as percentage based on federal funding (proxy for poverty)
        valid_indices = (~pd.isna(processed_data['rev_fed_total'])) & (~pd.isna(processed_data['student_enrollment'])) & (processed_data['student_enrollment'] > 0)
        processed_data.loc[valid_indices, 'poverty_rate'] = (processed_data.loc[valid_indices, 'rev_fed_total'] / processed_data.loc[valid_indices, 'student_enrollment']) * 0.01
    
    # Calculate funding per student if data available
    if 'funding_per_student' not in processed_data.columns and 'rev_total' in processed_data.columns and 'student_enrollment' in processed_data.columns:
        valid_indices = (~pd.isna(processed_data['rev_total'])) & (~pd.isna(processed_data['student_enrollment'])) & (processed_data['student_enrollment'] > 0)
        processed_data.loc[valid_indices, 'funding_per_student'] = processed_data.loc[valid_indices, 'rev_total'] / processed_data.loc[valid_indices, 'student_enrollment']
    
    # Calculate school count (use a placeholder if not available)
    if 'school_count' not in processed_data.columns:
        # Since we don't have actual school count, estimate based on student population
        if 'student_enrollment' in processed_data.columns:
            # Rough estimate: 1 school per 500 students, with minimum 1 school
            processed_data['school_count'] = np.ceil(processed_data['student_enrollment'] / 500).fillna(1).astype(int)
            # Ensure minimum is 1 school
            processed_data.loc[processed_data['school_count'] < 1, 'school_count'] = 1
    
    # Calculate schools per 1000 students (for visualization)
    if 'school_count' in processed_data.columns and 'student_enrollment' in processed_data.columns:
        valid_indices = (~pd.isna(processed_data['school_count'])) & (~pd.isna(processed_data['student_enrollment'])) & (processed_data['student_enrollment'] > 0)
        processed_data.loc[valid_indices, 'schools_per_1000'] = (processed_data.loc[valid_indices, 'school_count'] / processed_data.loc[valid_indices, 'student_enrollment']) * 1000
    
    # 5. Generate lat/long for mapping if not present
    # This is a simplified approach for visualization purposes
    if 'latitude' not in processed_data.columns or 'longitude' not in processed_data.columns:
        # Assign approximate coordinates by state or region
        # For demonstration purposes only - in a real application, use geocoding or proper coordinates
        state_coords = {
            'AL': (32.7794, -86.8287), 'CT': (41.6219, -72.7273), 'IA': (42.0751, -93.4960),
            'CA': (36.7783, -119.4179), 'WA': (47.7511, -120.7401), 'OR': (43.8041, -120.5542),
            'Midwest': (41.5000, -93.0000), 'Northeast': (42.5000, -72.0000), 
            'South': (33.0000, -85.0000), 'West': (39.0000, -120.0000)
        }
        
        # Add some random offset to points to spread them out
        processed_data['latitude'] = np.nan
        processed_data['longitude'] = np.nan
        
        # Use state if available, otherwise use region
        if 'state' in processed_data.columns:
            for state, (lat, lon) in state_coords.items():
                state_rows = processed_data['state'] == state
                if any(state_rows):
                    # Add random offset within a reasonable range (about +/- 50 miles)
                    count = state_rows.sum()
                    processed_data.loc[state_rows, 'latitude'] = lat + np.random.uniform(-0.5, 0.5, count)
                    processed_data.loc[state_rows, 'longitude'] = lon + np.random.uniform(-0.5, 0.5, count)
        
        # Fill remaining NaN coordinates with region-based coordinates
        if 'region' in processed_data.columns:
            for region, (lat, lon) in state_coords.items():
                if region in ['Midwest', 'Northeast', 'South', 'West']:
                    region_rows = (processed_data['region'] == region) & (pd.isna(processed_data['latitude']))
                    if any(region_rows):
                        count = region_rows.sum()
                        processed_data.loc[region_rows, 'latitude'] = lat + np.random.uniform(-1.0, 1.0, count)
                        processed_data.loc[region_rows, 'longitude'] = lon + np.random.uniform(-1.0, 1.0, count)
    
    # 6. Handle missing values for key metrics
    # We use median imputation for key values needed for scoring
    for col in ['poverty_rate', 'funding_per_student', 'school_count']:
        if col in processed_data.columns:
            # Group by region for more accurate imputation if possible
            if 'region' in processed_data.columns:
                # Calculate median by region
                region_medians = processed_data.groupby('region')[col].transform('median')
                # Use region median where values are missing
                processed_data[col] = processed_data[col].fillna(region_medians)
            
            # Fill any remaining NaNs with overall median
            if processed_data[col].isna().any():
                col_median = processed_data[col].median()
                processed_data[col] = processed_data[col].fillna(col_median)
    
    # 7. Filter to only include districts with cbsa_type as "Micropolitan statistical area"
    if 'cbsa_type' in processed_data.columns:
        processed_data = processed_data[processed_data['cbsa_type'] == 'Micropolitan statistical area']
    
    # Drop any rows that are still missing critical data after all processing
    critical_columns = ['district_name', 'student_enrollment', 'school_count']
    critical_columns = [col for col in critical_columns if col in processed_data.columns]
    processed_data = processed_data.dropna(subset=critical_columns)
    
    return processed_data

def filter_data(data, region=None, min_poverty_rate=None, max_poverty_rate=None):
    """
    Filter the dataset based on user-selected criteria.
    
    Args:
        data (DataFrame): The processed district data
        region (str, optional): Region to filter by
        min_poverty_rate (float, optional): Minimum poverty rate
        max_poverty_rate (float, optional): Maximum poverty rate
        
    Returns:
        DataFrame: Filtered dataset
    """
    filtered_data = data.copy()
    
    if region is not None and region != "All":
        filtered_data = filtered_data[filtered_data['region'] == region]
    
    if min_poverty_rate is not None:
        filtered_data = filtered_data[filtered_data['poverty_rate'] >= min_poverty_rate]
    
    if max_poverty_rate is not None:
        filtered_data = filtered_data[filtered_data['poverty_rate'] <= max_poverty_rate]
    
    return filtered_data

def get_geojson_data():
    """
    Create a simple GeoJSON structure for mapping.
    
    Since we don't have an actual GeoJSON file with district boundaries,
    we'll return a simplified version that allows the map to function.
    
    Returns:
        dict: Simplified GeoJSON data structure for mapping
    """
    # Create a simple GeoJSON structure
    # In a real implementation, this would load an actual GeoJSON file with proper boundaries
    
    geojson = {
        "type": "FeatureCollection",
        "features": []
    }
    
    # We'll return this simplified structure
    # The actual district points will be plotted using their lat/long coordinates
    # through the mapping function, not through this GeoJSON
    
    return geojson
